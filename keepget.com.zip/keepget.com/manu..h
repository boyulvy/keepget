/
|- index.html // 整合页面框架
|- home.html // 首页
|- whois.html // 域名验证中心
|- ip.html // IP工具箱
|- ranking.html // 域名测速排行榜
|- wallet.html // 钱包软件推荐
|- vpn.html  // VPN软件推荐
|- chat.html // 聊天软件推荐
|- download.html // 下载中心
|- tawk.html // 在线客服
|- contact.html // 页脚内容
|- style.css // 样式文件
|- script.js // 脚本文件